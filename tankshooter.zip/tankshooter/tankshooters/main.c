#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <windows.h>

#define GRID_WIDTH 20
#define GRID_HEIGHT 15
#define EMPTY ' '
#define WALL '#'
#define BULLET '*'

// Directions
#define DIR_UP 0
#define DIR_RIGHT 1
#define DIR_DOWN 2
#define DIR_LEFT 3

const char TANK_SYMBOLS[] = {'^', '>', 'v', '<'};
const char ENEMY_SYMBOL = 'E';

typedef struct {
    int x, y;
    int direction;
    int alive;
} Tank;

typedef struct {
    int x, y;
    int direction;
    int active;
} Bullet;

typedef struct {
    char cells[GRID_HEIGHT][GRID_WIDTH];
    Tank player;
    Tank enemy;
    Bullet bullet;
    int score;
    int gameOver;
    int won;
} Game;

// Hide cursor
void hideCursor() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO info;
    info.dwSize = 100;
    info.bVisible = FALSE;
    SetConsoleCursorInfo(consoleHandle, &info);
}

// Move cursor
void gotoxy(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// Initialize game
void initGame(Game *game) {
    srand(time(NULL));

    // Grid setup
    for (int y = 0; y < GRID_HEIGHT; y++) {
        for (int x = 0; x < GRID_WIDTH; x++) {
            if (y == 0 || y == GRID_HEIGHT - 1 || x == 0 || x == GRID_WIDTH - 1)
                game->cells[y][x] = WALL;
            else
                game->cells[y][x] = EMPTY;
        }
    }

    // Random obstacles
    for (int i = 0; i < 15; i++) {
        int x = rand() % (GRID_WIDTH - 4) + 2;
        int y = rand() % (GRID_HEIGHT - 4) + 2;
        game->cells[y][x] = WALL;
    }

    // Player
    game->player.x = 2;
    game->player.y = GRID_HEIGHT / 2;
    game->player.direction = DIR_RIGHT;
    game->player.alive = 1;

    // Enemy
    do {
        game->enemy.x = rand() % (GRID_WIDTH / 2) + GRID_WIDTH / 2 - 2;
        game->enemy.y = rand() % (GRID_HEIGHT - 4) + 2;
    } while (game->cells[game->enemy.y][game->enemy.x] == WALL);

    game->enemy.direction = DIR_LEFT;
    game->enemy.alive = 1;

    // Bullet
    game->bullet.active = 0;

    game->score = 0;
    game->gameOver = 0;
    game->won = 0;
}

// Render
void render(Game *game) {
    gotoxy(0, 0);

    printf("\n=== TANK SHOOTER ===\n");
    printf("Score: %d\n\n", game->score);

    for (int y = 0; y < GRID_HEIGHT; y++) {
        for (int x = 0; x < GRID_WIDTH; x++) {
            if (game->player.alive && x == game->player.x && y == game->player.y)
                printf("%c", TANK_SYMBOLS[game->player.direction]);
            else if (game->enemy.alive && x == game->enemy.x && y == game->enemy.y)
                printf("%c", ENEMY_SYMBOL);
            else if (game->bullet.active && x == game->bullet.x && y == game->bullet.y)
                printf("%c", BULLET);
            else
                printf("%c", game->cells[y][x]);
        }
        printf("\n");
    }

    printf("\nControls:\n");
    printf("W/A/S/D - Move\nSPACE - Shoot\nQ - Quit\n");
}

// Valid check
int isValid(Game *game, int x, int y) {
    if (x < 0 || x >= GRID_WIDTH || y < 0 || y >= GRID_HEIGHT)
        return 0;
    return game->cells[y][x] != WALL;
}

// Bullet update
void updateBullet(Game *game) {
    if (!game->bullet.active) return;

    int dx[] = {0, 1, 0, -1};
    int dy[] = {-1, 0, 1, 0};

    int newX = game->bullet.x + dx[game->bullet.direction];
    int newY = game->bullet.y + dy[game->bullet.direction];

    if (!isValid(game, newX, newY)) {
        game->bullet.active = 0;
        return;
    }

    if (game->enemy.alive && newX == game->enemy.x && newY == game->enemy.y) {
        game->enemy.alive = 0;
        game->bullet.active = 0;
        game->score += 100;
        game->won = 1;
        game->gameOver = 1;
        return;
    }

    game->bullet.x = newX;
    game->bullet.y = newY;
}

// Fire bullet
void fireBullet(Game *game) {
    if (game->bullet.active) return;

    int dx[] = {0, 1, 0, -1};
    int dy[] = {-1, 0, 1, 0};

    game->bullet.x = game->player.x + dx[game->player.direction];
    game->bullet.y = game->player.y + dy[game->player.direction];
    game->bullet.direction = game->player.direction;

    if (isValid(game, game->bullet.x, game->bullet.y))
        game->bullet.active = 1;
}

// Move player
void movePlayer(Game *game, int dir) {
    game->player.direction = dir;

    int dx[] = {0, 1, 0, -1};
    int dy[] = {-1, 0, 1, 0};

    int newX = game->player.x + dx[dir];
    int newY = game->player.y + dy[dir];

    if (!isValid(game, newX, newY)) return;

    if (game->enemy.alive && newX == game->enemy.x && newY == game->enemy.y) {
        game->gameOver = 1;
        return;
    }

    game->player.x = newX;
    game->player.y = newY;
}

// Enemy movement
void updateEnemy(Game *game) {
    if (!game->enemy.alive) return;

    if (rand() % 100 < 30) {
        int dx = (game->player.x < game->enemy.x) ? -1 : 1;
        int dy = (game->player.y < game->enemy.y) ? -1 : 1;

        int newX = game->enemy.x + dx;
        int newY = game->enemy.y + dy;

        if (isValid(game, newX, newY)) {
            game->enemy.x = newX;
            game->enemy.y = newY;
        }

        if (game->enemy.x == game->player.x && game->enemy.y == game->player.y) {
            game->gameOver = 1;
        }
    }
}

// Input
void input(Game *game) {
    if (_kbhit()) {
        char ch = _getch();

        switch (ch) {
            case 'w': case 'W': movePlayer(game, DIR_UP); break;
            case 'd': case 'D': movePlayer(game, DIR_RIGHT); break;
            case 's': case 'S': movePlayer(game, DIR_DOWN); break;
            case 'a': case 'A': movePlayer(game, DIR_LEFT); break;
            case ' ': fireBullet(game); break;
            case 'q': case 'Q': game->gameOver = 1; break;
        }
    }
}

int main() {
    char choice;

    do {
        Game game;

        system("cls");
        hideCursor();

        initGame(&game);

        // Game loop
        while (!game.gameOver) {
            input(&game);
            updateBullet(&game);
            updateEnemy(&game);
            render(&game);
            Sleep(80);
        }

        render(&game);

        if (game.won)
            printf("\nYOU WIN!\n");
        else
            printf("\nGAME OVER!\n");

        printf("Final Score: %d\n", game.score);

        printf("\nPlay again? (Y/N): ");
        scanf(" %c", &choice);

    } while (choice == 'y' || choice == 'Y');

    printf("\nThanks for playing!\n");
    return 0;
}
